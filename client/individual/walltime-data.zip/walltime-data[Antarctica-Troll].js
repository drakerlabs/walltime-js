/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Troll].js
    
    var tzData = {
        rules: {"Troll":[{"name":"Troll","_from":"2005","_to":"max","type":"-","in":"Mar","on":"lastSun","at":"1:00u","_save":"2:00","letter":"CEST"},{"name":"Troll","_from":"2004","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"1:00u","_save":"0:00","letter":"UTC"}]},
        zones: {"Antarctica/Troll":[{"name":"Antarctica/Troll","_offset":"0","_rule":"-","format":"zzz","_until":"2005 Feb 12"},{"name":"Antarctica/Troll","_offset":"0:00","_rule":"Troll","format":"%s","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);