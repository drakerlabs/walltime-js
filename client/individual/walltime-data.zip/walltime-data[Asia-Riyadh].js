/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Riyadh].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Riyadh":[{"name":"Asia/Riyadh","_offset":"3:06:52","_rule":"-","format":"LMT","_until":"1947 Mar 14"},{"name":"Asia/Riyadh","_offset":"3:00","_rule":"-","format":"AST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);