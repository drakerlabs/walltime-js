/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Guyana].js
    
    var tzData = {
        rules: {},
        zones: {"America/Guyana":[{"name":"America/Guyana","_offset":"-3:52:40","_rule":"-","format":"LMT","_until":"1915 Mar"},{"name":"America/Guyana","_offset":"-3:45","_rule":"-","format":"GBGT","_until":"1966 May 26"},{"name":"America/Guyana","_offset":"-3:45","_rule":"-","format":"GYT","_until":"1975 Jul 31"},{"name":"America/Guyana","_offset":"-3:00","_rule":"-","format":"GYT","_until":"1991"},{"name":"America/Guyana","_offset":"-4:00","_rule":"-","format":"GYT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);