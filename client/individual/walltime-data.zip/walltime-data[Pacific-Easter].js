/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Easter].js
    
    var tzData = {
        rules: {"Chile":[{"name":"Chile","_from":"1927","_to":"1931","type":"-","in":"Sep","on":"1","at":"0:00","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1928","_to":"1932","type":"-","in":"Apr","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"Chile","_from":"1968","_to":"only","type":"-","in":"Nov","on":"3","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1969","_to":"only","type":"-","in":"Mar","on":"30","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1969","_to":"only","type":"-","in":"Nov","on":"23","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1970","_to":"only","type":"-","in":"Mar","on":"29","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1971","_to":"only","type":"-","in":"Mar","on":"14","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1970","_to":"1972","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1972","_to":"1986","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1973","_to":"only","type":"-","in":"Sep","on":"30","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1974","_to":"1987","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1987","_to":"only","type":"-","in":"Apr","on":"12","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1988","_to":"1990","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1988","_to":"1989","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1990","_to":"only","type":"-","in":"Sep","on":"16","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1991","_to":"1996","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1991","_to":"1997","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1997","_to":"only","type":"-","in":"Mar","on":"30","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1998","_to":"only","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1998","_to":"only","type":"-","in":"Sep","on":"27","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"1999","_to":"only","type":"-","in":"Apr","on":"4","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"1999","_to":"2010","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"2000","_to":"2007","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2008","_to":"only","type":"-","in":"Mar","on":"30","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2009","_to":"only","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2010","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2011","_to":"only","type":"-","in":"May","on":"Sun>=2","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2011","_to":"only","type":"-","in":"Aug","on":"Sun>=16","at":"4:00u","_save":"1:00","letter":"S"},{"name":"Chile","_from":"2012","_to":"2015","type":"-","in":"Apr","on":"Sun>=23","at":"3:00u","_save":"0","letter":"-"},{"name":"Chile","_from":"2012","_to":"2014","type":"-","in":"Sep","on":"Sun>=2","at":"4:00u","_save":"1:00","letter":"S"}]},
        zones: {"Pacific/Easter":[{"name":"Pacific/Easter","_offset":"-7:17:28","_rule":"-","format":"LMT","_until":"1890"},{"name":"Pacific/Easter","_offset":"-7:17:28","_rule":"-","format":"EMT","_until":"1932 Sep"},{"name":"Pacific/Easter","_offset":"-7:00","_rule":"Chile","format":"EAS%sT","_until":"1982 Mar 14 3:00u"},{"name":"Pacific/Easter","_offset":"-6:00","_rule":"Chile","format":"EAS%sT","_until":"2015 Apr 26 3:00u"},{"name":"Pacific/Easter","_offset":"-5:00","_rule":"-","format":"EAST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);