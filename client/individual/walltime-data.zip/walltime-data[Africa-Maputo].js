/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Maputo].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Maputo":[{"name":"Africa/Maputo","_offset":"2:10:20","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Maputo","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);