/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Costa_Rica].js
    
    var tzData = {
        rules: {"CR":[{"name":"CR","_from":"1979","_to":"1980","type":"-","in":"Feb","on":"lastSun","at":"0:00","_save":"1:00","letter":"D"},{"name":"CR","_from":"1979","_to":"1980","type":"-","in":"Jun","on":"Sun>=1","at":"0:00","_save":"0","letter":"S"},{"name":"CR","_from":"1991","_to":"1992","type":"-","in":"Jan","on":"Sat>=15","at":"0:00","_save":"1:00","letter":"D"},{"name":"CR","_from":"1991","_to":"only","type":"-","in":"Jul","on":"1","at":"0:00","_save":"0","letter":"S"},{"name":"CR","_from":"1992","_to":"only","type":"-","in":"Mar","on":"15","at":"0:00","_save":"0","letter":"S"}]},
        zones: {"America/Costa_Rica":[{"name":"America/Costa_Rica","_offset":"-5:36:13","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Costa_Rica","_offset":"-5:36:13","_rule":"-","format":"SJMT","_until":"1921 Jan 15"},{"name":"America/Costa_Rica","_offset":"-6:00","_rule":"CR","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);