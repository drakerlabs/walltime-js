/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Syowa].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Syowa":[{"name":"Antarctica/Syowa","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Jan 29"},{"name":"Antarctica/Syowa","_offset":"3:00","_rule":"-","format":"SYOT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);