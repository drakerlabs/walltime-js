/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Lindeman].js
    
    var tzData = {
        rules: {"Aus":[{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Jan","on":"1","at":"0:01","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Mar","on":"25","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Jan","on":"1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Mar","on":"29","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Sep","on":"27","at":"2:00","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1943","_to":"1944","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1943","_to":"only","type":"-","in":"Oct","on":"3","at":"2:00","_save":"1:00","letter":"D"}],"AQ":[{"name":"AQ","_from":"1971","_to":"only","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AQ","_from":"1972","_to":"only","type":"-","in":"Feb","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AQ","_from":"1989","_to":"1991","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AQ","_from":"1990","_to":"1992","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"}],"Holiday":[{"name":"Holiday","_from":"1992","_to":"1993","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"Holiday","_from":"1993","_to":"1994","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"}]},
        zones: {"Australia/Lindeman":[{"name":"Australia/Lindeman","_offset":"9:55:56","_rule":"-","format":"LMT","_until":"1895"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"Aus","format":"AE%sT","_until":"1971"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"AQ","format":"AE%sT","_until":"1992 Jul"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"Holiday","format":"AE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);