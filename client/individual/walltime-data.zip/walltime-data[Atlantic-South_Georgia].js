/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-South_Georgia].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/South_Georgia":[{"name":"Atlantic/South_Georgia","_offset":"-2:26:08","_rule":"-","format":"LMT","_until":"1890"},{"name":"Atlantic/South_Georgia","_offset":"-2:00","_rule":"-","format":"GST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);