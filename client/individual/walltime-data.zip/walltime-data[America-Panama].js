/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Panama].js
    
    var tzData = {
        rules: {},
        zones: {"America/Panama":[{"name":"America/Panama","_offset":"-5:18:08","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Panama","_offset":"-5:19:36","_rule":"-","format":"CMT","_until":"1908 Apr 22"},{"name":"America/Panama","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);