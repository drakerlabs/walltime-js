/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Barbados].js
    
    var tzData = {
        rules: {"Barb":[{"name":"Barb","_from":"1977","_to":"only","type":"-","in":"Jun","on":"12","at":"2:00","_save":"1:00","letter":"D"},{"name":"Barb","_from":"1977","_to":"1978","type":"-","in":"Oct","on":"Sun>=1","at":"2:00","_save":"0","letter":"S"},{"name":"Barb","_from":"1978","_to":"1980","type":"-","in":"Apr","on":"Sun>=15","at":"2:00","_save":"1:00","letter":"D"},{"name":"Barb","_from":"1979","_to":"only","type":"-","in":"Sep","on":"30","at":"2:00","_save":"0","letter":"S"},{"name":"Barb","_from":"1980","_to":"only","type":"-","in":"Sep","on":"25","at":"2:00","_save":"0","letter":"S"}]},
        zones: {"America/Barbados":[{"name":"America/Barbados","_offset":"-3:58:29","_rule":"-","format":"LMT","_until":"1924"},{"name":"America/Barbados","_offset":"-3:58:29","_rule":"-","format":"BMT","_until":"1932"},{"name":"America/Barbados","_offset":"-4:00","_rule":"Barb","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);