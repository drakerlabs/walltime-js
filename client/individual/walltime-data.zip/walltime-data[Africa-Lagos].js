/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Lagos].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Lagos":[{"name":"Africa/Lagos","_offset":"0:13:36","_rule":"-","format":"LMT","_until":"1919 Sep"},{"name":"Africa/Lagos","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);