/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Regina].js
    
    var tzData = {
        rules: {"Regina":[{"name":"Regina","_from":"1918","_to":"only","type":"-","in":"Apr","on":"14","at":"2:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1918","_to":"only","type":"-","in":"Oct","on":"27","at":"2:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1930","_to":"1934","type":"-","in":"May","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1930","_to":"1934","type":"-","in":"Oct","on":"Sun>=1","at":"0:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1937","_to":"1941","type":"-","in":"Apr","on":"Sun>=8","at":"0:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1937","_to":"only","type":"-","in":"Oct","on":"Sun>=8","at":"0:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1938","_to":"only","type":"-","in":"Oct","on":"Sun>=1","at":"0:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1939","_to":"1941","type":"-","in":"Oct","on":"Sun>=8","at":"0:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1942","_to":"only","type":"-","in":"Feb","on":"9","at":"2:00","_save":"1:00","letter":"W"},{"name":"Regina","_from":"1945","_to":"only","type":"-","in":"Aug","on":"14","at":"23:00u","_save":"1:00","letter":"P"},{"name":"Regina","_from":"1945","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1946","_to":"only","type":"-","in":"Apr","on":"Sun>=8","at":"2:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1946","_to":"only","type":"-","in":"Oct","on":"Sun>=8","at":"2:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1947","_to":"1957","type":"-","in":"Apr","on":"lastSun","at":"2:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1947","_to":"1957","type":"-","in":"Sep","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Regina","_from":"1959","_to":"only","type":"-","in":"Apr","on":"lastSun","at":"2:00","_save":"1:00","letter":"D"},{"name":"Regina","_from":"1959","_to":"only","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0","letter":"S"}]},
        zones: {"America/Regina":[{"name":"America/Regina","_offset":"-6:58:36","_rule":"-","format":"LMT","_until":"1905 Sep"},{"name":"America/Regina","_offset":"-7:00","_rule":"Regina","format":"M%sT","_until":"1960 Apr lastSun 2:00"},{"name":"America/Regina","_offset":"-6:00","_rule":"-","format":"CST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);