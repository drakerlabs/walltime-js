/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Qatar].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Qatar":[{"name":"Asia/Qatar","_offset":"3:26:08","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Qatar","_offset":"4:00","_rule":"-","format":"GST","_until":"1972 Jun"},{"name":"Asia/Qatar","_offset":"3:00","_rule":"-","format":"AST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);