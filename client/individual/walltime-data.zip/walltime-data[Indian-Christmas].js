/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Indian-Christmas].js
    
    var tzData = {
        rules: {},
        zones: {"Indian/Christmas":[{"name":"Indian/Christmas","_offset":"7:02:52","_rule":"-","format":"LMT","_until":"1895 Feb"},{"name":"Indian/Christmas","_offset":"7:00","_rule":"-","format":"CXT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);