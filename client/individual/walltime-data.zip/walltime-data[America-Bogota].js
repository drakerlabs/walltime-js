/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Bogota].js
    
    var tzData = {
        rules: {"CO":[{"name":"CO","_from":"1992","_to":"only","type":"-","in":"May","on":"3","at":"0:00","_save":"1:00","letter":"S"},{"name":"CO","_from":"1993","_to":"only","type":"-","in":"Apr","on":"4","at":"0:00","_save":"0","letter":"-"}]},
        zones: {"America/Bogota":[{"name":"America/Bogota","_offset":"-4:56:16","_rule":"-","format":"LMT","_until":"1884 Mar 13"},{"name":"America/Bogota","_offset":"-4:56:16","_rule":"-","format":"BMT","_until":"1914 Nov 23"},{"name":"America/Bogota","_offset":"-5:00","_rule":"CO","format":"CO%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);