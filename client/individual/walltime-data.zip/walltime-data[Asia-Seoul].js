/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Seoul].js
    
    var tzData = {
        rules: {"ROK":[{"name":"ROK","_from":"1948","_to":"only","type":"-","in":"Jun","on":"1","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1948","_to":"only","type":"-","in":"Sep","on":"13","at":"0:00","_save":"0","letter":"S"},{"name":"ROK","_from":"1949","_to":"only","type":"-","in":"Apr","on":"3","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1949","_to":"1951","type":"-","in":"Sep","on":"Sun>=8","at":"0:00","_save":"0","letter":"S"},{"name":"ROK","_from":"1950","_to":"only","type":"-","in":"Apr","on":"1","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1951","_to":"only","type":"-","in":"May","on":"6","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1955","_to":"only","type":"-","in":"May","on":"5","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1955","_to":"only","type":"-","in":"Sep","on":"9","at":"0:00","_save":"0","letter":"S"},{"name":"ROK","_from":"1956","_to":"only","type":"-","in":"May","on":"20","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1956","_to":"only","type":"-","in":"Sep","on":"30","at":"0:00","_save":"0","letter":"S"},{"name":"ROK","_from":"1957","_to":"1960","type":"-","in":"May","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1957","_to":"1960","type":"-","in":"Sep","on":"Sun>=18","at":"0:00","_save":"0","letter":"S"},{"name":"ROK","_from":"1987","_to":"1988","type":"-","in":"May","on":"Sun>=8","at":"2:00","_save":"1:00","letter":"D"},{"name":"ROK","_from":"1987","_to":"1988","type":"-","in":"Oct","on":"Sun>=8","at":"3:00","_save":"0","letter":"S"}]},
        zones: {"Asia/Seoul":[{"name":"Asia/Seoul","_offset":"8:27:52","_rule":"-","format":"LMT","_until":"1908 Apr 1"},{"name":"Asia/Seoul","_offset":"8:30","_rule":"-","format":"KST","_until":"1912 Jan 1"},{"name":"Asia/Seoul","_offset":"9:00","_rule":"-","format":"JCST","_until":"1937 Oct 1"},{"name":"Asia/Seoul","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 8"},{"name":"Asia/Seoul","_offset":"9:00","_rule":"-","format":"KST","_until":"1954 Mar 21"},{"name":"Asia/Seoul","_offset":"8:30","_rule":"ROK","format":"K%sT","_until":"1961 Aug 10"},{"name":"Asia/Seoul","_offset":"9:00","_rule":"ROK","format":"K%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);