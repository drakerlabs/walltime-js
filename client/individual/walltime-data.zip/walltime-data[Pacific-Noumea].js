/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Noumea].js
    
    var tzData = {
        rules: {"NC":[{"name":"NC","_from":"1977","_to":"1978","type":"-","in":"Dec","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"S"},{"name":"NC","_from":"1978","_to":"1979","type":"-","in":"Feb","on":"27","at":"0:00","_save":"0","letter":"-"},{"name":"NC","_from":"1996","_to":"only","type":"-","in":"Dec","on":"1","at":"2:00s","_save":"1:00","letter":"S"},{"name":"NC","_from":"1997","_to":"only","type":"-","in":"Mar","on":"2","at":"2:00s","_save":"0","letter":"-"}]},
        zones: {"Pacific/Noumea":[{"name":"Pacific/Noumea","_offset":"11:05:48","_rule":"-","format":"LMT","_until":"1912 Jan 13"},{"name":"Pacific/Noumea","_offset":"11:00","_rule":"NC","format":"NC%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);