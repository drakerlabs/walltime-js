/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Accra].js
    
    var tzData = {
        rules: {"Ghana":[{"name":"Ghana","_from":"1920","_to":"1942","type":"-","in":"Sep","on":"1","at":"0:00","_save":"0:20","letter":"GHST"},{"name":"Ghana","_from":"1920","_to":"1942","type":"-","in":"Dec","on":"31","at":"0:00","_save":"0","letter":"GMT"}]},
        zones: {"Africa/Accra":[{"name":"Africa/Accra","_offset":"-0:00:52","_rule":"-","format":"LMT","_until":"1918"},{"name":"Africa/Accra","_offset":"0:00","_rule":"Ghana","format":"%s","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);