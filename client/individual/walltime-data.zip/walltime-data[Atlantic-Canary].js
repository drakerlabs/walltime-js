/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Canary].js
    
    var tzData = {
        rules: {"EU":[{"name":"EU","_from":"1977","_to":"1980","type":"-","in":"Apr","on":"Sun>=1","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1977","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1978","_to":"only","type":"-","in":"Oct","on":"1","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1979","_to":"1995","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1981","_to":"max","type":"-","in":"Mar","on":"lastSun","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1996","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"1:00u","_save":"0","letter":"-"}]},
        zones: {"Atlantic/Canary":[{"name":"Atlantic/Canary","_offset":"-1:01:36","_rule":"-","format":"LMT","_until":"1922 Mar"},{"name":"Atlantic/Canary","_offset":"-1:00","_rule":"-","format":"CANT","_until":"1946 Sep 30 1:00"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"-","format":"WET","_until":"1980 Apr 6 0:00s"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"1:00","format":"WEST","_until":"1980 Sep 28 1:00u"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"EU","format":"WE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);