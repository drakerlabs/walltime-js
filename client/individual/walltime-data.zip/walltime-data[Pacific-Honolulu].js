/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Honolulu].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Honolulu":[{"name":"Pacific/Honolulu","_offset":"-10:31:26","_rule":"-","format":"LMT","_until":"1896 Jan 13 12:00"},{"name":"Pacific/Honolulu","_offset":"-10:30","_rule":"-","format":"HST","_until":"1933 Apr 30 2:00"},{"name":"Pacific/Honolulu","_offset":"-10:30","_rule":"1:00","format":"HDT","_until":"1933 May 21 12:00"},{"name":"Pacific/Honolulu","_offset":"-10:30","_rule":"-","format":"HST","_until":"1942 Feb 9 2:00"},{"name":"Pacific/Honolulu","_offset":"-10:30","_rule":"1:00","format":"HDT","_until":"1945 Sep 30 2:00"},{"name":"Pacific/Honolulu","_offset":"-10:30","_rule":"-","format":"HST","_until":"1947 Jun 8 2:00"},{"name":"Pacific/Honolulu","_offset":"-10:00","_rule":"-","format":"HST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);