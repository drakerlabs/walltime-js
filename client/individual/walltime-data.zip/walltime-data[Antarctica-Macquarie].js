/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Macquarie].js
    
    var tzData = {
        rules: {"Aus":[{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Jan","on":"1","at":"0:01","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Mar","on":"25","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Jan","on":"1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Mar","on":"29","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Sep","on":"27","at":"2:00","_save":"1:00","letter":"D"},{"name":"Aus","_from":"1943","_to":"1944","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Aus","_from":"1943","_to":"only","type":"-","in":"Oct","on":"3","at":"2:00","_save":"1:00","letter":"D"}],"AT":[{"name":"AT","_from":"1967","_to":"only","type":"-","in":"Oct","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1968","_to":"only","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1968","_to":"1985","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1969","_to":"1971","type":"-","in":"Mar","on":"Sun>=8","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1972","_to":"only","type":"-","in":"Feb","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1973","_to":"1981","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1982","_to":"1983","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1984","_to":"1986","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1986","_to":"only","type":"-","in":"Oct","on":"Sun>=15","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1987","_to":"1990","type":"-","in":"Mar","on":"Sun>=15","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"1987","_to":"only","type":"-","in":"Oct","on":"Sun>=22","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1988","_to":"1990","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1991","_to":"1999","type":"-","in":"Oct","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"1991","_to":"2005","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"2000","_to":"only","type":"-","in":"Aug","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"2001","_to":"max","type":"-","in":"Oct","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"D"},{"name":"AT","_from":"2006","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"2007","_to":"only","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"AT","_from":"2008","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"}]},
        zones: {"Antarctica/Macquarie":[{"name":"Antarctica/Macquarie","_offset":"0","_rule":"-","format":"zzz","_until":"1899 Nov"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"-","format":"AEST","_until":"1916 Oct 1 2:00"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"1:00","format":"AEDT","_until":"1917 Feb"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"Aus","format":"AE%sT","_until":"1919 Apr 1 0:00s"},{"name":"Antarctica/Macquarie","_offset":"0","_rule":"-","format":"zzz","_until":"1948 Mar 25"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"Aus","format":"AE%sT","_until":"1967"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"AT","format":"AE%sT","_until":"2010 Apr 4 3:00"},{"name":"Antarctica/Macquarie","_offset":"11:00","_rule":"-","format":"MIST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);