/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Caracas].js
    
    var tzData = {
        rules: {},
        zones: {"America/Caracas":[{"name":"America/Caracas","_offset":"-4:27:44","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Caracas","_offset":"-4:27:40","_rule":"-","format":"CMT","_until":"1912 Feb 12"},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":"1965"},{"name":"America/Caracas","_offset":"-4:00","_rule":"-","format":"VET","_until":"2007 Dec 9 3:00"},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);