/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Apia].js
    
    var tzData = {
        rules: {"WS":[{"name":"WS","_from":"2010","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"0:00","_save":"1","letter":"D"},{"name":"WS","_from":"2011","_to":"only","type":"-","in":"Apr","on":"Sat>=1","at":"4:00","_save":"0","letter":"S"},{"name":"WS","_from":"2011","_to":"only","type":"-","in":"Sep","on":"lastSat","at":"3:00","_save":"1","letter":"D"},{"name":"WS","_from":"2012","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"4:00","_save":"0","letter":"S"},{"name":"WS","_from":"2012","_to":"max","type":"-","in":"Sep","on":"lastSun","at":"3:00","_save":"1","letter":"D"}]},
        zones: {"Pacific/Apia":[{"name":"Pacific/Apia","_offset":"12:33:04","_rule":"-","format":"LMT","_until":"1879 Jul 5"},{"name":"Pacific/Apia","_offset":"-11:26:56","_rule":"-","format":"LMT","_until":"1911"},{"name":"Pacific/Apia","_offset":"-11:30","_rule":"-","format":"WSST","_until":"1950"},{"name":"Pacific/Apia","_offset":"-11:00","_rule":"WS","format":"S%sT","_until":"2011 Dec 29 24:00"},{"name":"Pacific/Apia","_offset":"13:00","_rule":"WS","format":"WS%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);