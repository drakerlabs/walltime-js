/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Bougainville].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Bougainville":[{"name":"Pacific/Bougainville","_offset":"10:22:16","_rule":"-","format":"LMT","_until":"1880"},{"name":"Pacific/Bougainville","_offset":"9:48:32","_rule":"-","format":"PMMT","_until":"1895"},{"name":"Pacific/Bougainville","_offset":"10:00","_rule":"-","format":"PGT","_until":"1942 Jul"},{"name":"Pacific/Bougainville","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Aug 21"},{"name":"Pacific/Bougainville","_offset":"10:00","_rule":"-","format":"PGT","_until":"2014 Dec 28 2:00"},{"name":"Pacific/Bougainville","_offset":"11:00","_rule":"-","format":"BST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);