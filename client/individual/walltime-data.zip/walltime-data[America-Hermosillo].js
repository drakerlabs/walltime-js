/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Hermosillo].js
    
    var tzData = {
        rules: {"Mexico":[{"name":"Mexico","_from":"1939","_to":"only","type":"-","in":"Feb","on":"5","at":"0:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"1939","_to":"only","type":"-","in":"Jun","on":"25","at":"0:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"1940","_to":"only","type":"-","in":"Dec","on":"9","at":"0:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"1941","_to":"only","type":"-","in":"Apr","on":"1","at":"0:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"1943","_to":"only","type":"-","in":"Dec","on":"16","at":"0:00","_save":"1:00","letter":"W"},{"name":"Mexico","_from":"1944","_to":"only","type":"-","in":"May","on":"1","at":"0:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"1950","_to":"only","type":"-","in":"Feb","on":"12","at":"0:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"1950","_to":"only","type":"-","in":"Jul","on":"30","at":"0:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"1996","_to":"2000","type":"-","in":"Apr","on":"Sun>=1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"1996","_to":"2000","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"2001","_to":"only","type":"-","in":"May","on":"Sun>=1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"2001","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Mexico","_from":"2002","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Mexico","_from":"2002","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0","letter":"S"}]},
        zones: {"America/Hermosillo":[{"name":"America/Hermosillo","_offset":"-7:23:52","_rule":"-","format":"LMT","_until":"1921 Dec 31 23:36:08"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"-","format":"MST","_until":"1927 Jun 10 23:00"},{"name":"America/Hermosillo","_offset":"-6:00","_rule":"-","format":"CST","_until":"1930 Nov 15"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"-","format":"MST","_until":"1931 May 1 23:00"},{"name":"America/Hermosillo","_offset":"-6:00","_rule":"-","format":"CST","_until":"1931 Oct"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"-","format":"MST","_until":"1932 Apr 1"},{"name":"America/Hermosillo","_offset":"-6:00","_rule":"-","format":"CST","_until":"1942 Apr 24"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"-","format":"MST","_until":"1949 Jan 14"},{"name":"America/Hermosillo","_offset":"-8:00","_rule":"-","format":"PST","_until":"1970"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"Mexico","format":"M%sT","_until":"1999"},{"name":"America/Hermosillo","_offset":"-7:00","_rule":"-","format":"MST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);