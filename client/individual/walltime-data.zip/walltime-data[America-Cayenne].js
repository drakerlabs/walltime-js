/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Cayenne].js
    
    var tzData = {
        rules: {},
        zones: {"America/Cayenne":[{"name":"America/Cayenne","_offset":"-3:29:20","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"America/Cayenne","_offset":"-4:00","_rule":"-","format":"GFT","_until":"1967 Oct"},{"name":"America/Cayenne","_offset":"-3:00","_rule":"-","format":"GFT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);