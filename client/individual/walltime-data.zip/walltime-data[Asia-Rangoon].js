/*
 *  WallTime 0.2.0
 *  Copyright (c) 2015 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Rangoon].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Rangoon":[{"name":"Asia/Rangoon","_offset":"6:24:40","_rule":"-","format":"LMT","_until":"1880"},{"name":"Asia/Rangoon","_offset":"6:24:40","_rule":"-","format":"RMT","_until":"1920"},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"BURT","_until":"1942 May"},{"name":"Asia/Rangoon","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 May 3"},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"MMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define(function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);